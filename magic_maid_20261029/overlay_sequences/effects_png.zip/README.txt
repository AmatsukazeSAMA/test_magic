《魔法女仆》PV — 特效普通全片 PNG 序列

这是从附件1扁平原片估计的可见 特效 straight-alpha 素材，不是作者原始透明图层。
共 4763 张 PNG，F000000.png–F004762.png，画布 1920×1080。
每帧保持全画布与原位置，RGBA 8-bit，straight/unassociated alpha，alpha=0 处 RGB=0。
空透明帧不证明原片中没有字幕/特效；复杂遮挡及逐帧 status/metadata 仍需人工检查。
未重画人物；附件2只作参考、不提供像素。

文件：
- effects/Fxxxxxx.png：原片每一帧对应的独立普通 PNG。
- sequence.json：精确整数 PTS 与逐帧 duration_ticks。
- frame_mapping.json：该轨每帧 PNG SHA-256、内容寻址 ID、原片来源和提取状态。
- effects.ffconcat：相对路径 FFconcat，支持搬动文件夹。

时间轴：time_base=1/16000，总视频时长 2543333 ticks；
尾帧为 533 ticks。不要按固定 30fps 解释此序列。
FFconcat 最后一条重复文件仅为传达尾帧时长的哨兵，不是第 4764 个原片帧；
编码后需仅从视频移除哨兵，再单独完整 copy 原片音频，不用 -shortest。
源音频尾部到 158.997333 秒；本 ZIP 不重复包含音频，请使用 source/original.mp4。
仓库 scripts/magic_maid_overlays.py / magic_maid_timeline.py 包含精确 PTS 导出与编码示例。

两轨之间存在重叠、残余污染或不确定区域；请对照棋盘格预览与视觉审计再用于正式合成。
MP4 棋盘格预览不是 alpha 母版，真正的 alpha 素材是本包 PNG。
原始 alpha 没有恢复，production_ready=false；完整性验证通过不等于美术语义验收。
