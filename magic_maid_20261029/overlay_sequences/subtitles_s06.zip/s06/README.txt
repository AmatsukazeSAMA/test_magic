《魔法女仆》PV — s06 黑裙完整舞蹈 字幕 PNG 工作序列

本包只有字幕轨，不包含绘制任务数量或人物/复用统计。
s06 目录避免各 S 解压后互相覆盖。PNG 局部编号 L000000.png 起，共 1384 张。
画布 1920×1080，RGBA 8-bit，straight alpha，alpha=0 处 RGB=0；字节与全片验证过的字幕 PNG 完全相同。

sequence.json：local_frame/local_pts 是本包工作索引；source_frame/source_pts 是原片回合成位置。
frame_mapping.json：另含原片哈希、PNG/RGBA 哈希、提取 status/metadata。
subtitles_work_index.ffconcat：只把本 S 非连续出场顺接供工作检查，不是新的成片剪辑。
回合成必须使用 source_frame/source_pts，不可把 local_pts 当原片时间。
time_base=1/16000；逐帧使用 duration_ticks，不按固定 30fps 假定。
FFconcat 最后重复文件是尾帧时长哨兵，不是额外原片帧；编码后移除视频哨兵。
全片原视频截止2543333 ticks，原片F4762尾帧533 ticks；原音频到158.997333秒，单独保留完整音频尾。
s06 是全部黑裙舞蹈的同一个工作包，包含其多次回归，没有机械拆开。

这是从附件1扁平原片估计的可见字幕，不是作者原始透明图层。
附件2只参考，未重画人物；透明空帧不是没有字幕的证明。复杂遮挡/残留需人工复核。
完整性与 alpha 字节保持不等于美术语义验收，production_ready=false。
MP4棋盘格只作观看，不含alpha；真正的alpha在本包PNG。
